﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace M426_Projekt_CW_AD_JL_MB.Models.List
{
    public class ListViewModel
    {
        public List<ListModel> Lists { get; set; }
    }
}
