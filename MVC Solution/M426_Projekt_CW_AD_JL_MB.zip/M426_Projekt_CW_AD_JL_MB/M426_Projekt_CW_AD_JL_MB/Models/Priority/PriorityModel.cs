﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace M426_Projekt_CW_AD_JL_MB.Models.Priority
{
    public class PriorityModel
    {
        public int Id { get; set; }
        public string name { get; set; }
        public int emphasis { get; set; }
    }
}
